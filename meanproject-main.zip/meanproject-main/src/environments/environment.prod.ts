export const environment = {
  production: true,
  secret:'winopapa',
  client:'123456789',
  urlBackend:'http://localhost:3000/'
};
